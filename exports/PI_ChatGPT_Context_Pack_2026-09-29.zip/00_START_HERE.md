# Product Intelligence context pack

This pack is for explaining the Steele Product Intelligence (PI) project to someone who has not seen the repository. The files are flat in this folder so they can be attached individually if needed.

## Read in this order

1. `Product_Intelligence_Discovery_Handoff_2026-09-29.md` — current project context, completed research, important results, limitations, and the Creatnet–Dalgo responsibility split. Start here.
2. `Steele Intel - Product Brief and Dev Roadmap.docx` — original product vision and proposed features. Most product goals remain relevant, but its plan for Creatnet to build the aggregation database is superseded. Its dates and technology choices need fresh confirmation.
3. `ga4_discovery_current_state.md` — detailed historical Shopify–GA4 investigation and evidence behind the handoff's numbers. It was written before the Dalgo decision; read its database design suggestions as earlier proposals.
4. `README.md` — map of the discovery repository, what its scripts do, and technical follow-ups. The scripts are experiments, not a production system.

## Current facts to keep straight

- Dalgo, from Project Tech4Dev, handles data aggregation and the database.
- Creatnet owns product analytics, dashboards, later ML work, and any missing connector. A needed production connector will be built in the Dalgo repository.
- Shopify and GA4 have useful completed discovery. Meta work was interrupted early and is explicitly incomplete.
- Saved July 2026 results are historical snapshots, not current performance figures. The agreement details, live Dalgo setup, source coverage, and timeline are not documented in this pack.

## A prompt you can paste into ChatGPT

> Please read all attached files, starting with `00_START_HERE.md` and then the handoff. Teach me this project from the beginning in simple language. First explain the business problem and the current Creatnet–Dalgo division of work. Then explain, source by source, exactly what was done in this repository, what the evidence supports, what remains incomplete, and what changed from the original brief. Define technical terms as you introduce them. Distinguish confirmed facts from historical proposals and open questions. After teaching me the past work, suggest a prioritized plan for the next phase of product discovery using official documentation, stakeholder research, and Dalgo discussions. Ask me for missing information before treating unknown contract or connector details as facts.

This pack omits raw exports, tokens, and local configuration files. If a specific finding needs checking, return to the original repository and inspect only the relevant evidence with suitable data-use controls.
