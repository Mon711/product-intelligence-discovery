"""Meta discovery scripts."""
