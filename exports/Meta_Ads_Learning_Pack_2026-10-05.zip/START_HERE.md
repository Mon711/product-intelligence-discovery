# Start here: Steele Meta Ads learning pack

Prepared 5 October 2026. This is a local teaching snapshot, not a complete runnable repository or a current advertising report.

## Use with ChatGPT or another AI chatbot

1. Read or attach `docs/Meta_Ads_Code_Learning_Handoff_2026-10-05.md` first. It includes project background, before/after behavior, the execution flow, important functions, metric interpretation, limitations, and verification instructions.
2. For source-based teaching, attach the selected `.py` files. Start with the command, then reporting, then the reader, then tests. `auth.py` explains the existing configuration-path dependency.
3. If your chatbot cannot inspect ZIP files, extract this archive and attach the documents/source individually. If its attachment limit is small, start with the handoff and three main code files, then add tests when needed.
4. `SOURCE_MANIFEST.json` records original paths, source fingerprints, the base Git revision, and the uncommitted state. The new code is a working-tree snapshot and is not contained in the base commit alone.

## Paste this prompt

I am learning the Meta Ads changes in Steele's Product Intelligence discovery project. Read the attached learning handoff first, then the source files if available. Assume I have no prior knowledge of APIs, authentication, reporting, or this codebase. Start with the project's purpose, then explain how the command, restricted reader, and exporter work together during a one-day run. Define technical terms immediately in plain language. Walk through important functions and blocks with their purpose, inputs, outputs, reasons, assumptions, and failures. Use the supplied source as evidence and do not invent missing behavior. Distinguish implemented code, offline tests, dated live checks, and remaining unknowns. Explain why purchases, reach, missing values, dates, and attribution need careful interpretation. Do not default to quizzes. Do not ask for secrets, run live queries, change advertising assets, or propose production infrastructure as part of teaching. If files cannot be read, identify what you can explain from the handoff and what needs actual source. Begin with the overall flow; let me ask for deeper detail.

## Important evidence boundary

The implementation's 23 offline tests passed, and live account access plus a one-day Insights sample worked. Two partial export attempts are marked failed after interruption/rate limiting. A complete September export and live completion of the final revised creative-reading path remain unverified. No live API was called to prepare this learning pack.

## Contents and exclusions

Original paths are preserved. The pack includes selected source/tests, two package markers, dependency settings, this read-first file, the learning handoff, and the manifest. It excludes local configuration/credentials, raw reports/customer records, logs, dependencies, browser state, and the rest of the repository. Existing unrelated work was preserved. Local packaging does not mean the files were uploaded anywhere. Treat the internal project context as work material when deciding where to share it.
